To run the Code:
- Place the target calibration images in the `Calibration_imgs` folder in the directory.
- Currently the folder is empty because of size issues for the submission.
- Run the following command in the terminal to get the new Calbration parameters and reprojection error:

```
python Wrapper.py
``` 
