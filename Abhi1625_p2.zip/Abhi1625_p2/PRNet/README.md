## To run PRnet:



1. Download the PRN trained model at BaiduDrive or GoogleDrive, and put it into Data/net-data

2. Convert the video for faceswapping into frames by using ffmpeg:
	use command= 'ffmpeg -r 1 Test1.mp4 -r  "test%0d.png"'

3. Feed the path to the swapping files by using command:
	'python demo_texture.py -i image_path_1 -r image_path_2 -o output_path'
